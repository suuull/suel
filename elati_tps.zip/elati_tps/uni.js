const express=require('express');
const app=express();
const mysql=require('mysql');

let conn=mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"",
    database:"uni"
})

app.get('/courses',(req,res)=>{
    conn.query("SELECT * FROM corsi",(error,result)=>{
        if(error) throw err;
        else {
            
            res.json("result");
            app.listen
        }
    })
})
app.get('/courses/:codiceCorso',(req,res)=>{
    conn.query("SELECT * FROM ",(error,result)=>{
        if(error) throw err;
        else {
            
            res.json("result");
            app.listen
        }
    })
})
app.get('/students',(req,res)=>{
    conn.query("SELECT * FROM studenti",(error,result)=>{
        if(error) throw err;
        else {
            
            res.json("result");
            app.listen
        }
    })
})

app.listen(3000,()=>{
    console.log("in ascolto...");
    conn.connect();
})
